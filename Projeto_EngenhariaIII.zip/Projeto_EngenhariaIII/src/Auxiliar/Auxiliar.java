package Auxiliar;

import java.util.List;

import Controller.CadastroController;
import Model.Cadastro;

public class Auxiliar {

	private CadastroController cadastroController;
	
	public Auxiliar(){
		this.cadastroController = new CadastroController();
	}
	
	public void inserir(Cadastro cadastro){
		this.cadastroController.Inserir(cadastro);
	}
	
}
