package Util;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import Model.Cadastro;

public class CadastroModeloTabela extends AbstractTableModel{

	private List<Cadastro> cadastros;
	
	public CadastroModeloTabela(List<Cadastro> cadastros){
		this.cadastros = cadastros;
	}
	
	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public int getRowCount() {
		return this.cadastros.size();
	}

	public String getColumnName(final int column){
		switch(column){
                case 0:
			return "cod_livro";
		case 1:
			return "titulo";
		case 2:
			return "numeropaginas";
		case 3:
			return "genero";
                case 4:
                        return "sinopse";
			default: return "?";
		}
	}
	
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Cadastro cadastro = cadastros.get(rowIndex);
		
		switch(columnIndex){
                case 0:
			return cadastro.getId();
		case 1:
			return cadastro.getTitulo();
		case 2:
			return cadastro.getNumPaginas();
		case 3:
			return cadastro.getGenero();
                case 4:
                        return cadastro.getSinopse();
			default: return null;
		}
		
	}
	
	public Cadastro getCadastro(int rowIndex){
		Cadastro cadastro = cadastros.get(rowIndex);
		return cadastro;
	}
	
	public boolean isCellEditable(int rowIndex, int columnIndex){
		return false;
	}
	

}
