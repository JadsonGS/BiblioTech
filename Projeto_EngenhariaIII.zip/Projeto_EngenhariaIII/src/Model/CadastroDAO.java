package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Conexao.Conexao;

public class CadastroDAO {

	private Connection connection = null;
	private PreparedStatement stm = null;
	
	public void inserir(Cadastro cadastro){
		String sql = "INSERT INTO livro (cod_livro, titulo, numeropaginas, genero, sinopse) VALUES (?,?,?,?,?);";
	
		try{
			this.connection = new Conexao().getConexao();
			this.stm=this.connection.prepareStatement(sql);
                        this.stm.setInt(1, cadastro.getId());
			this.stm.setString(2, cadastro.getTitulo());
			this.stm.setInt(3, cadastro.getNumPaginas());
                        this.stm.setString(4, cadastro.getGenero());
			this.stm.setString(5, cadastro.getSinopse());
			this.stm.execute();
			this.stm.close();
		}catch(SQLException e){
			throw new RuntimeException(e);
		}finally{
			try{
				this.connection.close();
			}catch(SQLException e){
				throw new RuntimeException(e);
			}
		}
	}
}
	
