package Model;

import java.util.Calendar;

public class Cadastro {
	
        public int id;
	public String titulo;
	public int num_paginas;
	public String genero;
        public String sinopse;
        public int getId() {
		return id;
	}
        public void setId(int Id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getNumPaginas() {
		return num_paginas;
	}
	public void setNumPaginas(int num_paginas) {
		this.num_paginas = num_paginas;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
        public String getSinopse() {
		return sinopse;
        }
        public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}
}
	
	