package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

	private String url = "jdbc:mysql://localhost/mvc";
	private String user = "root";
	private String pass = "guilherme2019";
	
	public Connection getConexao(){
                Connection conn = null;
            try {        
                conn = DriverManager.getConnection(url, user, pass);
                System.out.println("Conectado");
		} catch(SQLException e){
                    System.err.println("Falha na conexão");
		}
            return conn;
	}
}
