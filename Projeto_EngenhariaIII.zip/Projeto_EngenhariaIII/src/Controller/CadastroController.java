package Controller;

import java.util.List;

import javax.swing.JOptionPane;

import Model.Cadastro;
import Model.CadastroDAO;

public class CadastroController {

	private CadastroDAO dao;
	
	public CadastroController(){
		this.dao = new CadastroDAO();
	}
	
	public void Inserir(Cadastro cadastro){
                int id;
                int num_paginas;
                
                id = cadastro.getId();
       
		if(cadastro != null && Integer.parseInt(!cadastro.getId().equals(null))
                        && !cadastro.getTitulo().equals("") 
                        && Integer.parseInt(!cadastro.getNumPaginas().equals(null))
                        && !cadastro.getGenero().equals("") 
                        && !cadastro.getSinopse().equals("")){
			dao.inserir(cadastro);
			JOptionPane.showMessageDialog(null, "Cadastro concluido com sucesso!");
		} else {
			JOptionPane.showMessageDialog(null, "Todos os campos são necessários!");
		}
	}
}
